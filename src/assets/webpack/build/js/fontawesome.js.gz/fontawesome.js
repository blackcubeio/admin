(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["fontawesome"],{

/***/ "./scss/fontawesome.scss":
/*!*******************************!*\
  !*** ./scss/fontawesome.scss ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

},[["./scss/fontawesome.scss","manifest"]]]);
//# sourceMappingURL=fontawesome.js.map