(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./scss/style.scss":
/*!*************************!*\
  !*** ./scss/style.scss ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

},[["./scss/style.scss","manifest"]]]);
//# sourceMappingURL=main.js.map